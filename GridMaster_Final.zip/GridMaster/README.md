# 🎮 Grid Master - Jogo da Velha

![Grid Master](app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png)

## 📱 Sobre o Projeto

**Grid Master** é um jogo da velha completo e profissional para Android com design neon futurista, modo contra robô com IA Minimax e modo online multiplayer via Firebase.

---

## ✨ Funcionalidades

| Funcionalidade | Descrição |
|---|---|
| 🤖 **VS Robô** | IA com algoritmo Minimax + Alpha-Beta Pruning |
| 🌐 **Online** | Multiplayer em tempo real via Firebase |
| 👥 **2 Jogadores** | Modo local no mesmo dispositivo |
| 📊 **Estatísticas** | Vitórias, derrotas, sequências, conquistas |
| ⚙️ **Configurações** | Nome, dificuldade, som, vibração |
| 🎨 **Design Neon** | Visual futurista com efeitos de brilho |
| 🔊 **Sons & Vibração** | Feedback tátil e sonoro imersivo |
| 🏆 **Conquistas** | Badges por desempenho |

---

## 🤖 Dificuldades da IA

- **Fácil** → 30% de jogadas inteligentes + random
- **Médio** → Sempre bloqueia/vence, Minimax profundidade 4
- **Difícil** → Minimax completo com Alpha-Beta Pruning (imbatível)

---

## 🏗️ Estrutura do Projeto

```
GridMaster/
├── app/src/main/
│   ├── java/com/gridmaster/game/
│   │   ├── activities/
│   │   │   ├── SplashActivity.kt         # Tela de abertura animada
│   │   │   ├── MainActivity.kt           # Menu principal
│   │   │   ├── GameActivity.kt           # Jogo vs Robô / 2 Jogadores
│   │   │   ├── GameViewModel.kt          # Lógica de estado do jogo
│   │   │   ├── OnlineGameActivity.kt     # Jogo online
│   │   │   ├── MatchmakingActivity.kt    # Sala online / matchmaking
│   │   │   ├── SettingsActivity.kt       # Configurações
│   │   │   └── StatsActivity.kt          # Estatísticas
│   │   ├── ai/
│   │   │   └── AIEngine.kt              # IA Minimax com Alpha-Beta Pruning
│   │   ├── models/
│   │   │   └── GameModels.kt            # Board, Player, OnlineRoom, Stats
│   │   ├── network/
│   │   │   └── OnlineRepository.kt      # Firebase Realtime Database
│   │   ├── utils/
│   │   │   ├── SoundManager.kt          # Gerenciamento de sons
│   │   │   ├── PreferencesManager.kt    # Preferências e estatísticas
│   │   │   └── Extensions.kt           # Animações e extensões
│   │   └── views/
│   │       └── GameBoardView.kt         # View customizada do tabuleiro
│   └── res/
│       ├── drawable/                    # Imagens geradas (splash, cells, avatars)
│       ├── layout/                      # Todos os layouts XML
│       ├── values/                      # Colors, strings, themes, dimens
│       └── mipmap-*/                    # Ícones do launcher (todas as densidades)
```

---

## 🚀 Como Compilar

### Pré-requisitos
- Android Studio Hedgehog (2023.1.1) ou superior
- JDK 17
- Android SDK API 34
- Conta Firebase (para modo online)

### Passos

1. **Clone ou abra o projeto no Android Studio**

2. **Configure o Firebase**
   - Acesse [Firebase Console](https://console.firebase.google.com)
   - Crie um novo projeto
   - Adicione um app Android com o package: `com.gridmaster.game`
   - Baixe o `google-services.json` e substitua o arquivo em `app/`
   - Ative o **Realtime Database** no Firebase Console

3. **Sincronize o Gradle**
   ```
   File → Sync Project with Gradle Files
   ```

4. **Compile e execute**
   ```
   Run → Run 'app'
   ```

---

## 🌐 Configuração do Firebase (Modo Online)

No Firebase Console, vá em **Realtime Database → Rules** e configure:

```json
{
  "rules": {
    "rooms": {
      "$roomId": {
        ".read": true,
        ".write": true
      }
    },
    "matchmaking": {
      ".read": true,
      ".write": true
    }
  }
}
```

> ⚠️ Para produção, adicione autenticação e regras mais restritivas.

---

## 📦 Dependências Principais

```gradle
- AndroidX Core KTX 1.12.0
- Material Components 1.11.0
- Firebase BOM 32.6.0 (Database + Auth)
- Kotlin Coroutines 1.7.3
- ViewModel + LiveData 2.6.2
- Lottie 6.1.0 (animações)
- Glide 4.16.0 (imagens)
```

---

## 🎨 Paleta de Cores

| Cor | Hex | Uso |
|-----|-----|-----|
| Fundo Escuro | `#0F0F23` | Background principal |
| Azul Neon | `#64DCFF` | Jogador O, acentos |
| Rosa Neon | `#FF64B4` | Jogador X, acentos |
| Roxo | `#8C50FF` | Online, acentos |
| Verde | `#50DC78` | Vitória, stats |
| Dourado | `#FFD750` | Linha vencedora, estrelas |

---

## 📱 Telas do App

1. **Splash** – Logo animado com starfield
2. **Menu Principal** – Cards de modo, stats rápidas
3. **Jogo** – Tabuleiro neon com efeitos de brilho
4. **Online/Matchmaking** – Criação de sala, código de convite
5. **Configurações** – Nome, dificuldade, som
6. **Estatísticas** – Métricas completas + conquistas

---

## 👨‍💻 Tecnologias

- **Linguagem**: Kotlin 100%
- **Arquitetura**: MVVM (ViewModel + LiveData)
- **Backend**: Firebase Realtime Database
- **Algoritmo IA**: Minimax + Alpha-Beta Pruning
- **UI**: Material Design 3 + Custom Views
- **Async**: Kotlin Coroutines + Flow
- **Build**: Gradle 8.0 + Kotlin DSL

---

*Grid Master — Feito com ❤️ e muita IA*
