package com.gridmaster.game.views

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import com.gridmaster.game.models.Board
import com.gridmaster.game.models.Player
import kotlin.math.min

/**
 * Custom view that draws the Tic-Tac-Toe board with neon effects.
 */
class GameBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    // ─── Callbacks ────────────────────────────────────────────────────────────
    var onCellClicked: ((Int) -> Unit)? = null

    // ─── State ────────────────────────────────────────────────────────────────
    private var board: Board = Board()
    private var winningCombo: IntArray? = null
    private var isEnabled2: Boolean = true
    private var highlightCell: Int = -1
    private var cellAnimations = FloatArray(9) { 0f }
    private var winLineProgress: Float = 0f

    // ─── Paints ───────────────────────────────────────────────────────────────
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 60, 80, 160)
        strokeWidth = 6f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val gridGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 100, 150, 255)
        strokeWidth = 18f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        maskFilter = BlurMaskFilter(12f, BlurMaskFilter.Blur.NORMAL)
    }

    private val xPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(240, 255, 100, 180)
        strokeWidth = 14f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val xGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(80, 255, 100, 180)
        strokeWidth = 28f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        maskFilter = BlurMaskFilter(16f, BlurMaskFilter.Blur.NORMAL)
    }

    private val oPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(240, 100, 220, 255)
        strokeWidth = 14f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val oGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(80, 100, 220, 255)
        strokeWidth = 28f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        maskFilter = BlurMaskFilter(16f, BlurMaskFilter.Blur.NORMAL)
    }

    private val cellBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val winLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 255, 215, 80)
        strokeWidth = 10f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        maskFilter = BlurMaskFilter(20f, BlurMaskFilter.Blur.NORMAL)
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 60, 80, 160)
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }

    // ─── Layout ───────────────────────────────────────────────────────────────
    private var cellSize: Float = 0f
    private var boardOffset: Float = 0f
    private val cellPadding: Float = 18f
    private val cornerRadius: Float = 24f

    // ─── Public API ───────────────────────────────────────────────────────────

    fun setBoard(newBoard: Board) {
        val prev = board
        board = newBoard
        // Animate new moves
        for (i in 0..8) {
            if (prev.cells[i] == Player.NONE && newBoard.cells[i] != Player.NONE) {
                animateCell(i)
            }
        }
        invalidate()
    }

    fun setWinningCombo(combo: IntArray?) {
        winningCombo = combo
        if (combo != null) animateWinLine()
        invalidate()
    }

    fun setBoardEnabled(enabled: Boolean) {
        isEnabled2 = enabled
        invalidate()
    }

    fun resetBoard() {
        board = Board()
        winningCombo = null
        winLineProgress = 0f
        cellAnimations = FloatArray(9) { 0f }
        invalidate()
    }

    // ─── Measure ─────────────────────────────────────────────────────────────

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = min(
            MeasureSpec.getSize(widthMeasureSpec),
            MeasureSpec.getSize(heightMeasureSpec)
        )
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val boardSize = min(w, h).toFloat() - 40f
        cellSize     = boardSize / 3f
        boardOffset  = (min(w, h) - boardSize) / 2f
    }

    // ─── Draw ─────────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawCellBackgrounds(canvas)
        drawGrid(canvas)
        drawPieces(canvas)
        drawWinLine(canvas)
    }

    private fun drawCellBackgrounds(canvas: Canvas) {
        for (row in 0..2) {
            for (col in 0..2) {
                val i  = row * 3 + col
                val cx = boardOffset + col * cellSize
                val cy = boardOffset + row * cellSize

                val bgColor = when {
                    winningCombo?.contains(i) == true ->
                        Color.argb(100, 255, 215, 80)
                    board.cells[i] == Player.X ->
                        Color.argb(60, 255, 100, 180)
                    board.cells[i] == Player.O ->
                        Color.argb(60, 100, 220, 255)
                    i == highlightCell ->
                        Color.argb(80, 100, 140, 255)
                    else ->
                        Color.argb(50, 25, 35, 80)
                }
                cellBgPaint.color = bgColor
                canvas.drawRoundRect(
                    cx + cellPadding, cy + cellPadding,
                    cx + cellSize - cellPadding, cy + cellSize - cellPadding,
                    cornerRadius, cornerRadius, cellBgPaint
                )
                // Border
                borderPaint.color = Color.argb(
                    if (winningCombo?.contains(i) == true) 200 else 80,
                    60, 80, 160
                )
                canvas.drawRoundRect(
                    cx + cellPadding, cy + cellPadding,
                    cx + cellSize - cellPadding, cy + cellSize - cellPadding,
                    cornerRadius, cornerRadius, borderPaint
                )
            }
        }
    }

    private fun drawGrid(canvas: Canvas) {
        // Horizontal lines
        for (i in 1..2) {
            val y = boardOffset + i * cellSize
            canvas.drawLine(boardOffset + cellPadding, y, boardOffset + 3 * cellSize - cellPadding, y, gridGlowPaint)
            canvas.drawLine(boardOffset + cellPadding, y, boardOffset + 3 * cellSize - cellPadding, y, gridPaint)
        }
        // Vertical lines
        for (i in 1..2) {
            val x = boardOffset + i * cellSize
            canvas.drawLine(x, boardOffset + cellPadding, x, boardOffset + 3 * cellSize - cellPadding, gridGlowPaint)
            canvas.drawLine(x, boardOffset + cellPadding, x, boardOffset + 3 * cellSize - cellPadding, gridPaint)
        }
    }

    private fun drawPieces(canvas: Canvas) {
        for (row in 0..2) {
            for (col in 0..2) {
                val i     = row * 3 + col
                val cx    = boardOffset + col * cellSize + cellSize / 2f
                val cy    = boardOffset + row * cellSize + cellSize / 2f
                val scale = cellAnimations[i]
                val pad   = cellSize * 0.28f

                when (board.cells[i]) {
                    Player.X -> {
                        canvas.save()
                        canvas.scale(scale, scale, cx, cy)
                        // Glow
                        canvas.drawLine(cx - pad, cy - pad, cx + pad, cy + pad, xGlowPaint)
                        canvas.drawLine(cx + pad, cy - pad, cx - pad, cy + pad, xGlowPaint)
                        // Main
                        canvas.drawLine(cx - pad, cy - pad, cx + pad, cy + pad, xPaint)
                        canvas.drawLine(cx + pad, cy - pad, cx - pad, cy + pad, xPaint)
                        canvas.restore()
                    }
                    Player.O -> {
                        canvas.save()
                        canvas.scale(scale, scale, cx, cy)
                        val r = pad * 0.9f
                        // Glow
                        canvas.drawCircle(cx, cy, r, oGlowPaint)
                        // Main
                        canvas.drawCircle(cx, cy, r, oPaint)
                        canvas.restore()
                    }
                    else -> {}
                }
            }
        }
    }

    private fun drawWinLine(canvas: Canvas) {
        val combo = winningCombo ?: return
        if (winLineProgress <= 0f) return

        val a = combo[0]; val b = combo[2]
        val row0 = a / 3; val col0 = a % 3
        val row2 = b / 3; val col2 = b % 3
        val startX = boardOffset + col0 * cellSize + cellSize / 2f
        val startY = boardOffset + row0 * cellSize + cellSize / 2f
        val endX   = boardOffset + col2 * cellSize + cellSize / 2f
        val endY   = boardOffset + row2 * cellSize + cellSize / 2f

        val currentX = startX + (endX - startX) * winLineProgress
        val currentY = startY + (endY - startY) * winLineProgress

        canvas.drawLine(startX, startY, currentX, currentY, winLinePaint)
    }

    // ─── Animations ───────────────────────────────────────────────────────────

    private fun animateCell(index: Int) {
        ValueAnimator.ofFloat(0f, 1.3f, 1f).apply {
            duration = 350
            interpolator = OvershootInterpolator(3f)
            addUpdateListener {
                cellAnimations[index] = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun animateWinLine() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 600
            interpolator = android.view.animation.DecelerateInterpolator()
            addUpdateListener {
                winLineProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    // ─── Touch ────────────────────────────────────────────────────────────────

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled2) return false

        val x = event.x - boardOffset
        val y = event.y - boardOffset

        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val col = (x / cellSize).toInt()
                val row = (y / cellSize).toInt()
                if (col in 0..2 && row in 0..2) {
                    val i = row * 3 + col
                    if (board.isValidMove(i)) {
                        highlightCell = i
                        invalidate()
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                val col = (x / cellSize).toInt()
                val row = (y / cellSize).toInt()
                highlightCell = -1
                if (col in 0..2 && row in 0..2) {
                    val i = row * 3 + col
                    if (board.isValidMove(i)) {
                        onCellClicked?.invoke(i)
                    }
                }
                invalidate()
            }
        }
        return true
    }
}
