package com.gridmaster.game.activities

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.gridmaster.game.databinding.ActivityGameBinding
import com.gridmaster.game.models.*
import com.gridmaster.game.utils.*

class GameActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_GAME_MODE = "game_mode"
    }

    private lateinit var binding: ActivityGameBinding
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupGame()
        observeViewModel()
        setupListeners()
    }

    private fun setupGame() {
        val modeName = intent.getStringExtra(EXTRA_GAME_MODE) ?: GameMode.VS_ROBOT.name
        viewModel.gameMode  = GameMode.valueOf(modeName)
        viewModel.difficulty = PreferencesManager.difficulty
        viewModel.humanPlayer = Player.X
        viewModel.aiPlayer    = Player.O

        // Update UI labels
        when (viewModel.gameMode) {
            GameMode.VS_ROBOT -> {
                binding.tvPlayer1Name.text = "👤 ${PreferencesManager.playerName}"
                binding.tvPlayer2Name.text = "🤖 Robô (${viewModel.difficulty.displayName()})"
                binding.ivPlayer2Avatar.setImageResource(com.gridmaster.game.R.drawable.robot_avatar)
            }
            GameMode.LOCAL_TWO_PLAYER -> {
                binding.tvPlayer1Name.text = "👤 Jogador 1"
                binding.tvPlayer2Name.text = "👤 Jogador 2"
                binding.ivPlayer2Avatar.setImageResource(com.gridmaster.game.R.drawable.player_avatar)
            }
            else -> {}
        }

        binding.ivPlayer1Avatar.setImageResource(com.gridmaster.game.R.drawable.player_avatar)
        binding.tvTitle.text = when (viewModel.gameMode) {
            GameMode.VS_ROBOT        -> "VS ROBÔ"
            GameMode.LOCAL_TWO_PLAYER -> "2 JOGADORES"
            else                     -> "PARTIDA"
        }
    }

    private fun observeViewModel() {
        viewModel.board.observe(this) { board ->
            binding.gameBoardView.setBoard(board)
        }

        viewModel.currentTurn.observe(this) { player ->
            updateTurnIndicator(player)
        }

        viewModel.gameResult.observe(this) { result ->
            result ?: return@observe
            onGameEnd(result)
        }

        viewModel.aiThinking.observe(this) { thinking ->
            binding.progressAiThinking.visibility = if (thinking) View.VISIBLE else View.GONE
            binding.gameBoardView.setBoardEnabled(!thinking)
        }

        viewModel.aiMessage.observe(this) { msg ->
            binding.tvAiMessage.apply {
                if (msg != null) {
                    text = msg
                    animateFadeIn(300)
                } else {
                    animateFadeOut(200)
                }
            }
        }

        viewModel.scoreX.observe(this) { score ->
            binding.tvScoreX.text = score.toString()
        }
        viewModel.scoreO.observe(this) { score ->
            binding.tvScoreO.text = score.toString()
        }
        viewModel.drawCount.observe(this) { draws ->
            binding.tvScoreDraw.text = draws.toString()
        }
    }

    private fun setupListeners() {
        binding.gameBoardView.onCellClicked = { index ->
            SoundManager.playMove()
            viewModel.makeMove(index)
        }

        binding.btnRestart.setOnClickListener {
            SoundManager.playClick()
            it.animateBounce()
            binding.layoutGameOver.animateFadeOut(200)
            binding.gameBoardView.resetBoard()
            viewModel.restartGame()
        }

        binding.btnBack.setOnClickListener {
            SoundManager.playClick()
            onBackPressed()
        }

        binding.btnSwitchSides.setOnClickListener {
            SoundManager.playClick()
            it.animateBounce()
            binding.layoutGameOver.animateFadeOut(200)
            binding.gameBoardView.resetBoard()
            viewModel.switchSides()
        }
    }

    private fun updateTurnIndicator(player: Player) {
        val isP1 = player == Player.X
        binding.apply {
            cardPlayer1.animate().alpha(if (isP1) 1f else 0.45f).setDuration(250).start()
            cardPlayer2.animate().alpha(if (!isP1) 1f else 0.45f).setDuration(250).start()

            tvCurrentTurn.text = when {
                viewModel.gameMode == GameMode.VS_ROBOT && player == viewModel.aiPlayer ->
                    "🤖 Vez do Robô"
                isP1 -> "⚡ Vez do X"
                else -> "⚡ Vez do O"
            }
        }
    }

    private fun onGameEnd(result: GameResult) {
        // Show win combo on board
        binding.gameBoardView.setWinningCombo(result.winningCombo)
        binding.gameBoardView.setBoardEnabled(false)

        // Play sound
        val isHumanWin = result.winner == viewModel.humanPlayer ||
                         (viewModel.gameMode == GameMode.LOCAL_TWO_PLAYER && result.winner != Player.NONE)
        when {
            result.gameState == GameState.DRAW -> SoundManager.playDraw()
            isHumanWin || viewModel.gameMode == GameMode.LOCAL_TWO_PLAYER && result.winner == Player.X ->
                SoundManager.playWin()
            else -> SoundManager.playLose()
        }

        // Show game over overlay
        binding.apply {
            val bannerRes = when (result.gameState) {
                GameState.PLAYER_X_WIN -> {
                    if (viewModel.humanPlayer == Player.X || viewModel.gameMode == GameMode.LOCAL_TWO_PLAYER)
                        com.gridmaster.game.R.drawable.banner_win
                    else com.gridmaster.game.R.drawable.banner_lose
                }
                GameState.PLAYER_O_WIN -> {
                    if (viewModel.humanPlayer == Player.O)
                        com.gridmaster.game.R.drawable.banner_win
                    else com.gridmaster.game.R.drawable.banner_lose
                }
                else -> com.gridmaster.game.R.drawable.banner_draw
            }
            ivResultBanner.setImageResource(bannerRes)

            val resultText = when (result.gameState) {
                GameState.PLAYER_X_WIN -> {
                    if (viewModel.gameMode == GameMode.LOCAL_TWO_PLAYER) "JOGADOR 1 VENCEU!"
                    else if (viewModel.humanPlayer == Player.X) "VOCÊ VENCEU! 🎉"
                    else "ROBÔ VENCEU! 🤖"
                }
                GameState.PLAYER_O_WIN -> {
                    if (viewModel.gameMode == GameMode.LOCAL_TWO_PLAYER) "JOGADOR 2 VENCEU!"
                    else if (viewModel.humanPlayer == Player.O) "VOCÊ VENCEU! 🎉"
                    else "ROBÔ VENCEU! 🤖"
                }
                else -> "EMPATE! 🤝"
            }
            tvResultText.text = resultText

            layoutGameOver.animatePop()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
