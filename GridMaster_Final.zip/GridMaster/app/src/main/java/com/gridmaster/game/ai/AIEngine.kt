package com.gridmaster.game.ai

import com.gridmaster.game.models.Board
import com.gridmaster.game.models.Difficulty
import com.gridmaster.game.models.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.random.Random

/**
 * Grid Master AI Engine
 *
 * Uses the Minimax algorithm with Alpha-Beta pruning for HARD difficulty.
 * EASY  → random valid move (30% smart)
 * MEDIUM → minimax depth-limited + 40% random
 * HARD   → perfect minimax (unbeatable)
 */
object AIEngine {

    private val aiPlayer   = Player.O
    private val humanPlayer = Player.X

    // ─── Public API ──────────────────────────────────────────────────────────

    suspend fun getBestMove(board: Board, difficulty: Difficulty): Int {
        return withContext(Dispatchers.Default) {
            // Simulate thinking time for realism
            val thinkMs = when (difficulty) {
                Difficulty.EASY   -> Random.nextLong(300, 700)
                Difficulty.MEDIUM -> Random.nextLong(500, 1000)
                Difficulty.HARD   -> Random.nextLong(700, 1400)
            }
            delay(thinkMs)

            when (difficulty) {
                Difficulty.EASY   -> getEasyMove(board)
                Difficulty.MEDIUM -> getMediumMove(board)
                Difficulty.HARD   -> getHardMove(board)
            }
        }
    }

    // ─── Difficulty Logic ─────────────────────────────────────────────────────

    private fun getEasyMove(board: Board): Int {
        val moves = board.getAvailableMoves()
        if (moves.isEmpty()) return -1

        // 30% chance to play smart (win if possible)
        if (Random.nextFloat() < 0.30f) {
            val smart = findWinningMove(board, aiPlayer)
                ?: findWinningMove(board, humanPlayer)
            if (smart != null) return smart
        }
        return moves.random()
    }

    private fun getMediumMove(board: Board): Int {
        val moves = board.getAvailableMoves()
        if (moves.isEmpty()) return -1

        // Always block or win
        findWinningMove(board, aiPlayer)?.let { return it }
        findWinningMove(board, humanPlayer)?.let { return it }

        // 40% chance to play randomly after blocking
        if (Random.nextFloat() < 0.40f) {
            // Prefer center or corners
            val preferred = listOf(4, 0, 2, 6, 8).filter { board.isValidMove(it) }
            if (preferred.isNotEmpty()) return preferred.random()
            return moves.random()
        }

        // Depth-limited minimax
        return minimaxBestMove(board, depth = 4)
    }

    private fun getHardMove(board: Board): Int {
        val moves = board.getAvailableMoves()
        if (moves.isEmpty()) return -1
        return minimaxBestMove(board, depth = 9)
    }

    // ─── Helper: Find immediate winning/blocking move ─────────────────────────

    private fun findWinningMove(board: Board, player: Player): Int? {
        for (index in board.getAvailableMoves()) {
            val newBoard = board.makeMove(index, player)
            if (newBoard.checkWinner() == player) return index
        }
        return null
    }

    // ─── Minimax with Alpha-Beta Pruning ─────────────────────────────────────

    private fun minimaxBestMove(board: Board, depth: Int): Int {
        var bestScore = Int.MIN_VALUE
        var bestMove = board.getAvailableMoves().firstOrNull() ?: return -1

        for (move in board.getAvailableMoves()) {
            val newBoard = board.makeMove(move, aiPlayer)
            val score = minimax(newBoard, depth - 1, false, Int.MIN_VALUE, Int.MAX_VALUE)
            if (score > bestScore) {
                bestScore = score
                bestMove = move
            }
        }
        return bestMove
    }

    private fun minimax(board: Board, depth: Int, isMaximizing: Boolean,
                        alpha: Int, beta: Int): Int {
        val winner = board.checkWinner()

        // Terminal states
        if (winner == aiPlayer)    return 10 + depth
        if (winner == humanPlayer) return -10 - depth
        if (board.isFull() || depth == 0) return 0

        var alphaVar = alpha
        var betaVar  = beta

        return if (isMaximizing) {
            var maxEval = Int.MIN_VALUE
            for (move in board.getAvailableMoves()) {
                val eval = minimax(board.makeMove(move, aiPlayer), depth - 1, false, alphaVar, betaVar)
                maxEval = maxOf(maxEval, eval)
                alphaVar = maxOf(alphaVar, eval)
                if (betaVar <= alphaVar) break // Beta cutoff
            }
            maxEval
        } else {
            var minEval = Int.MAX_VALUE
            for (move in board.getAvailableMoves()) {
                val eval = minimax(board.makeMove(move, humanPlayer), depth - 1, true, alphaVar, betaVar)
                minEval = minOf(minEval, eval)
                betaVar = minOf(betaVar, eval)
                if (betaVar <= alphaVar) break // Alpha cutoff
            }
            minEval
        }
    }

    // ─── AI Personality Messages ──────────────────────────────────────────────

    fun getAIThinkingMessage(): String {
        val messages = listOf(
            "🤖 Calculando...",
            "🤖 Analisando o tabuleiro...",
            "🤖 Processando estratégia...",
            "🤖 Hmm, interessante...",
            "🤖 Executando algoritmo...",
            "🤖 Verificando possibilidades..."
        )
        return messages.random()
    }

    fun getAIWinMessage(): String {
        val messages = listOf(
            "🤖 Minha lógica é superior!",
            "🤖 Calculei cada movimento!",
            "🤖 Previsível, humano.",
            "🤖 Minha vitória era inevitável.",
            "🤖 Tente novamente... se ousar!"
        )
        return messages.random()
    }

    fun getAILoseMessage(): String {
        val messages = listOf(
            "🤖 Impossível! Vou recalibrar!",
            "🤖 Você me surpreendeu!",
            "🤖 Vitória merecida, humano.",
            "🤖 Erro nos cálculos detectado.",
            "🤖 Próxima rodada será diferente!"
        )
        return messages.random()
    }

    fun getAIDrawMessage(): String {
        val messages = listOf(
            "🤖 Empate perfeito. Respeito.",
            "🤖 Você resistiu bem.",
            "🤖 Combate equilibrado.",
            "🤖 Nenhum de nós é melhor... por enquanto."
        )
        return messages.random()
    }
}
