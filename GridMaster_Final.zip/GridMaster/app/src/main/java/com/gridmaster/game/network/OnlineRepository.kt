package com.gridmaster.game.network

import com.google.firebase.database.*
import com.gridmaster.game.models.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

/**
 * Firebase Realtime Database repository for online multiplayer.
 *
 * Rooms schema:
 *   /rooms/{roomId}/  →  OnlineRoom data
 *
 * Matchmaking schema:
 *   /matchmaking/{userId}/ → { userId, name, timestamp }
 */
object OnlineRepository {

    private val db: FirebaseDatabase by lazy {
        FirebaseDatabase.getInstance().apply {
            setPersistenceEnabled(true)
        }
    }

    private val roomsRef: DatabaseReference get() = db.getReference("rooms")
    private val matchmakingRef: DatabaseReference get() = db.getReference("matchmaking")

    // ─── Room Management ─────────────────────────────────────────────────────

    suspend fun createRoom(hostId: String, hostName: String): OnlineRoom {
        val room = OnlineRoom(
            hostId   = hostId,
            hostName = hostName,
            hostIsX  = true,
            gameState = GameState.WAITING
        )
        roomsRef.child(room.roomId).setValue(room.toFirebaseMap()).await()
        return room
    }

    suspend fun joinRoom(roomId: String, guestId: String, guestName: String): OnlineRoom? {
        val snapshot = roomsRef.child(roomId).get().await()
        val map = snapshot.value as? Map<*, *> ?: return null
        val room = OnlineRoom.fromFirebaseMap(map) ?: return null

        if (room.gameState != GameState.WAITING) return null
        if (room.guestId.isNotEmpty()) return null

        val updatedRoom = room.copy(
            guestId   = guestId,
            guestName = guestName,
            gameState = GameState.PLAYING
        )
        roomsRef.child(roomId).setValue(updatedRoom.toFirebaseMap()).await()
        return updatedRoom
    }

    suspend fun makeMove(roomId: String, index: Int, room: OnlineRoom): Boolean {
        return try {
            val newBoard = room.board.makeMove(index, room.currentTurn)
            val winner   = newBoard.checkWinner()
            val newState = when {
                winner != Player.NONE -> if (winner == Player.X) GameState.PLAYER_X_WIN
                                        else GameState.PLAYER_O_WIN
                newBoard.isFull()    -> GameState.DRAW
                else                 -> GameState.PLAYING
            }
            val updatedRoom = room.copy(
                board        = newBoard,
                currentTurn  = room.currentTurn.opponent(),
                gameState    = newState,
                lastMoveTime = System.currentTimeMillis()
            )
            roomsRef.child(roomId).setValue(updatedRoom.toFirebaseMap()).await()
            true
        } catch (e: Exception) { false }
    }

    suspend fun abandonRoom(roomId: String) {
        roomsRef.child(roomId).child("gameState").setValue(GameState.ABANDONED.name).await()
    }

    suspend fun deleteRoom(roomId: String) {
        roomsRef.child(roomId).removeValue().await()
    }

    // ─── Room Observer ───────────────────────────────────────────────────────

    fun observeRoom(roomId: String): Flow<OnlineRoom?> = callbackFlow {
        val ref      = roomsRef.child(roomId)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val map  = snapshot.value as? Map<*, *>
                val room = map?.let { OnlineRoom.fromFirebaseMap(it) }
                trySend(room)
            }
            override fun onCancelled(error: DatabaseError) {
                trySend(null)
            }
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    // ─── Matchmaking ─────────────────────────────────────────────────────────

    suspend fun joinMatchmaking(userId: String, playerName: String): String? {
        // Look for an existing waiting player
        val snapshot = matchmakingRef
            .orderByChild("timestamp")
            .limitToFirst(10)
            .get()
            .await()

        for (child in snapshot.children) {
            val data      = child.value as? Map<*, *> ?: continue
            val waitingId = data["userId"] as? String ?: continue

            if (waitingId == userId) continue // Skip self

            // Found a match – remove from queue and create room
            val waitingName = data["playerName"] as? String ?: "Player"
            matchmakingRef.child(waitingId).removeValue().await()

            val room = createRoom(waitingId, waitingName)
            return joinRoom(room.roomId, userId, playerName)?.roomId
        }

        // No match found – add to queue
        val entry = mapOf(
            "userId"     to userId,
            "playerName" to playerName,
            "timestamp"  to ServerValue.TIMESTAMP
        )
        matchmakingRef.child(userId).setValue(entry).await()
        return null // Waiting
    }

    suspend fun cancelMatchmaking(userId: String) {
        matchmakingRef.child(userId).removeValue().await()
    }

    fun observeMatchmaking(userId: String): Flow<String?> = callbackFlow {
        // Watch for a room where we become guest
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Check if userId was picked up
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        // Listen to rooms looking for our userId as guest
        val ref = roomsRef.orderByChild("guestId").equalTo(userId)
        val roomListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (child in snapshot.children) {
                    trySend(child.key)
                    return
                }
                trySend(null)
            }
            override fun onCancelled(error: DatabaseError) { trySend(null) }
        }
        ref.addValueEventListener(roomListener)
        awaitClose { ref.removeEventListener(roomListener) }
    }

    // ─── Generate Guest User ID ───────────────────────────────────────────────

    fun generateGuestId(): String = "guest_${UUID.randomUUID().toString().take(8)}"
}
