package com.gridmaster.game.utils

import android.content.Context
import android.content.SharedPreferences
import com.gridmaster.game.models.Difficulty
import com.gridmaster.game.models.PlayerStats

object PreferencesManager {

    private lateinit var prefs: SharedPreferences
    private const val PREFS_NAME = "grid_master_prefs"

    // Keys
    private const val KEY_PLAYER_NAME     = "player_name"
    private const val KEY_PLAYER_ID       = "player_id"
    private const val KEY_DIFFICULTY      = "difficulty"
    private const val KEY_SOUND_ENABLED   = "sound_enabled"
    private const val KEY_VIBRATION       = "vibration_enabled"
    private const val KEY_THEME           = "theme"
    private const val KEY_TOTAL_GAMES     = "total_games"
    private const val KEY_WINS            = "wins"
    private const val KEY_LOSSES          = "losses"
    private const val KEY_DRAWS           = "draws"
    private const val KEY_WINS_VS_ROBOT   = "wins_vs_robot"
    private const val KEY_LOSSES_VS_ROBOT = "losses_vs_robot"
    private const val KEY_ONLINE_WINS     = "online_wins"
    private const val KEY_ONLINE_LOSSES   = "online_losses"
    private const val KEY_WIN_STREAK      = "win_streak"
    private const val KEY_BEST_STREAK     = "best_streak"
    private const val KEY_FIRST_LAUNCH    = "first_launch"

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getString(KEY_PLAYER_ID, null) == null) {
            prefs.edit().putString(KEY_PLAYER_ID, OnlineRepository.generateGuestId()).apply()
        }
    }

    var playerName: String
        get() = prefs.getString(KEY_PLAYER_NAME, "Jogador") ?: "Jogador"
        set(v) = prefs.edit().putString(KEY_PLAYER_NAME, v).apply()

    val playerId: String
        get() = prefs.getString(KEY_PLAYER_ID, "") ?: ""

    var difficulty: Difficulty
        get() = try {
            Difficulty.valueOf(prefs.getString(KEY_DIFFICULTY, "MEDIUM") ?: "MEDIUM")
        } catch (e: Exception) { Difficulty.MEDIUM }
        set(v) = prefs.edit().putString(KEY_DIFFICULTY, v.name).apply()

    var isSoundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND_ENABLED, true)
        set(v) {
            prefs.edit().putBoolean(KEY_SOUND_ENABLED, v).apply()
            SoundManager.isSoundEnabled = v
        }

    var isVibrationEnabled: Boolean
        get() = prefs.getBoolean(KEY_VIBRATION, true)
        set(v) {
            prefs.edit().putBoolean(KEY_VIBRATION, v).apply()
            SoundManager.isVibrationEnabled = v
        }

    val isFirstLaunch: Boolean
        get() {
            val first = prefs.getBoolean(KEY_FIRST_LAUNCH, true)
            if (first) prefs.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply()
            return first
        }

    // ─── Stats ──────────────────────────────────────────────────────────────

    fun getStats(): PlayerStats = PlayerStats(
        totalGames    = prefs.getInt(KEY_TOTAL_GAMES, 0),
        wins          = prefs.getInt(KEY_WINS, 0),
        losses        = prefs.getInt(KEY_LOSSES, 0),
        draws         = prefs.getInt(KEY_DRAWS, 0),
        winsVsRobot   = prefs.getInt(KEY_WINS_VS_ROBOT, 0),
        lossesVsRobot = prefs.getInt(KEY_LOSSES_VS_ROBOT, 0),
        onlineWins    = prefs.getInt(KEY_ONLINE_WINS, 0),
        onlineLosses  = prefs.getInt(KEY_ONLINE_LOSSES, 0),
        winStreak     = prefs.getInt(KEY_WIN_STREAK, 0),
        bestStreak    = prefs.getInt(KEY_BEST_STREAK, 0)
    )

    fun recordWin(vsRobot: Boolean = false, online: Boolean = false) {
        val streak = prefs.getInt(KEY_WIN_STREAK, 0) + 1
        val best   = maxOf(prefs.getInt(KEY_BEST_STREAK, 0), streak)
        prefs.edit()
            .putInt(KEY_TOTAL_GAMES, prefs.getInt(KEY_TOTAL_GAMES, 0) + 1)
            .putInt(KEY_WINS, prefs.getInt(KEY_WINS, 0) + 1)
            .putInt(KEY_WIN_STREAK, streak)
            .putInt(KEY_BEST_STREAK, best)
            .apply {
                if (vsRobot)  putInt(KEY_WINS_VS_ROBOT, prefs.getInt(KEY_WINS_VS_ROBOT, 0) + 1)
                if (online)   putInt(KEY_ONLINE_WINS,   prefs.getInt(KEY_ONLINE_WINS, 0) + 1)
            }
            .apply()
    }

    fun recordLoss(vsRobot: Boolean = false, online: Boolean = false) {
        prefs.edit()
            .putInt(KEY_TOTAL_GAMES, prefs.getInt(KEY_TOTAL_GAMES, 0) + 1)
            .putInt(KEY_LOSSES, prefs.getInt(KEY_LOSSES, 0) + 1)
            .putInt(KEY_WIN_STREAK, 0)
            .apply {
                if (vsRobot) putInt(KEY_LOSSES_VS_ROBOT, prefs.getInt(KEY_LOSSES_VS_ROBOT, 0) + 1)
                if (online)  putInt(KEY_ONLINE_LOSSES,   prefs.getInt(KEY_ONLINE_LOSSES, 0) + 1)
            }
            .apply()
    }

    fun recordDraw() {
        prefs.edit()
            .putInt(KEY_TOTAL_GAMES, prefs.getInt(KEY_TOTAL_GAMES, 0) + 1)
            .putInt(KEY_DRAWS, prefs.getInt(KEY_DRAWS, 0) + 1)
            .putInt(KEY_WIN_STREAK, 0)
            .apply()
    }

    fun resetStats() {
        listOf(KEY_TOTAL_GAMES, KEY_WINS, KEY_LOSSES, KEY_DRAWS,
            KEY_WINS_VS_ROBOT, KEY_LOSSES_VS_ROBOT, KEY_ONLINE_WINS,
            KEY_ONLINE_LOSSES, KEY_WIN_STREAK, KEY_BEST_STREAK
        ).forEach { key -> prefs.edit().putInt(key, 0).apply() }
    }
}
