package com.gridmaster.game

import android.app.Application
import android.content.Context
import com.google.firebase.FirebaseApp
import com.gridmaster.game.utils.SoundManager
import com.gridmaster.game.utils.PreferencesManager

class GridMasterApp : Application() {

    companion object {
        lateinit var instance: GridMasterApp
            private set

        fun getContext(): Context = instance.applicationContext
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Initialize Firebase
        FirebaseApp.initializeApp(this)

        // Initialize managers
        SoundManager.init(this)
        PreferencesManager.init(this)
    }

    override fun onTerminate() {
        super.onTerminate()
        SoundManager.release()
    }
}
