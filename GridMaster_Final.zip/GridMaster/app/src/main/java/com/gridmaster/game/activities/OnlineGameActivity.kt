package com.gridmaster.game.activities

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gridmaster.game.databinding.ActivityOnlineGameBinding
import com.gridmaster.game.models.*
import com.gridmaster.game.network.OnlineRepository
import com.gridmaster.game.utils.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class OnlineGameActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ROOM_ID   = "room_id"
        const val EXTRA_PLAYER_ID = "player_id"
        const val EXTRA_IS_HOST   = "is_host"
    }

    private lateinit var binding: ActivityOnlineGameBinding
    private lateinit var roomId: String
    private lateinit var myPlayerId: String
    private var isHost: Boolean = true
    private var mySymbol: Player = Player.X
    private var currentRoom: OnlineRoom? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnlineGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        roomId     = intent.getStringExtra(EXTRA_ROOM_ID)   ?: ""
        myPlayerId = intent.getStringExtra(EXTRA_PLAYER_ID) ?: ""
        isHost     = intent.getBooleanExtra(EXTRA_IS_HOST, true)
        mySymbol   = if (isHost) Player.X else Player.O

        setupUI()
        observeRoom()
    }

    private fun setupUI() {
        binding.apply {
            tvMySymbol.text = "Você é: ${mySymbol.symbol()}"
            tvRoomCode.text = "Sala: $roomId"

            tvPlayer1Name.text = if (isHost) PreferencesManager.playerName else "Adversário"
            tvPlayer2Name.text = if (!isHost) PreferencesManager.playerName else "Adversário"

            btnLeave.setOnClickListener {
                SoundManager.playClick()
                lifecycleScope.launch {
                    OnlineRepository.abandonRoom(roomId)
                    finish()
                }
            }

            gameBoardView.onCellClicked = { index ->
                val room = currentRoom ?: return@onCellClicked
                if (room.currentTurn == mySymbol && room.gameState == GameState.PLAYING) {
                    SoundManager.playMove()
                    lifecycleScope.launch {
                        OnlineRepository.makeMove(roomId, index, room)
                    }
                }
            }
        }
    }

    private fun observeRoom() {
        lifecycleScope.launch {
            OnlineRepository.observeRoom(roomId).collectLatest { room ->
                room ?: return@collectLatest
                currentRoom = room
                updateUI(room)
            }
        }
    }

    private fun updateUI(room: OnlineRoom) {
        binding.apply {
            // Update names when guest joins
            tvPlayer1Name.text = room.hostName
            tvPlayer2Name.text = if (room.guestId.isEmpty()) "Aguardando..." else room.guestName

            // Waiting for opponent
            if (room.gameState == GameState.WAITING) {
                tvStatus.text = "⏳ Aguardando oponente..."
                tvStatus.visibility = View.VISIBLE
                gameBoardView.setBoardEnabled(false)
                return
            }

            // Update board
            gameBoardView.setBoard(room.board)

            // Turn indicator
            val isMyTurn = room.currentTurn == mySymbol && room.gameState == GameState.PLAYING
            gameBoardView.setBoardEnabled(isMyTurn)

            tvStatus.text = when {
                room.gameState == GameState.PLAYING && isMyTurn -> "⚡ Sua vez!"
                room.gameState == GameState.PLAYING -> "⏳ Vez do oponente..."
                else -> ""
            }
            tvStatus.visibility = if (tvStatus.text.isEmpty()) View.GONE else View.VISIBLE

            cardPlayer1.animate().alpha(if (room.currentTurn == Player.X) 1f else 0.4f).setDuration(250).start()
            cardPlayer2.animate().alpha(if (room.currentTurn == Player.O) 1f else 0.4f).setDuration(250).start()

            // Game over
            when (room.gameState) {
                GameState.PLAYER_X_WIN, GameState.PLAYER_O_WIN, GameState.DRAW -> {
                    gameBoardView.setWinningCombo(room.board.getWinningCombo())
                    gameBoardView.setBoardEnabled(false)
                    showOnlineResult(room)
                }
                GameState.ABANDONED -> {
                    tvResultText.text = "🚫 Oponente abandonou!"
                    layoutGameOver.animatePop()
                }
                else -> {}
            }
        }
    }

    private fun showOnlineResult(room: OnlineRoom) {
        val iWon = (room.gameState == GameState.PLAYER_X_WIN && mySymbol == Player.X) ||
                   (room.gameState == GameState.PLAYER_O_WIN && mySymbol == Player.O)
        val isDraw = room.gameState == GameState.DRAW

        when {
            isDraw -> {
                SoundManager.playDraw()
                binding.tvResultText.text = "🤝 EMPATE!"
                binding.ivResultBanner.setImageResource(com.gridmaster.game.R.drawable.banner_draw)
                PreferencesManager.recordDraw()
            }
            iWon -> {
                SoundManager.playWin()
                binding.tvResultText.text = "🏆 VOCÊ VENCEU!"
                binding.ivResultBanner.setImageResource(com.gridmaster.game.R.drawable.banner_win)
                PreferencesManager.recordWin(online = true)
            }
            else -> {
                SoundManager.playLose()
                binding.tvResultText.text = "😔 VOCÊ PERDEU!"
                binding.ivResultBanner.setImageResource(com.gridmaster.game.R.drawable.banner_lose)
                PreferencesManager.recordLoss(online = true)
            }
        }

        binding.layoutGameOver.animatePop()

        binding.btnPlayAgain.setOnClickListener {
            SoundManager.playClick()
            lifecycleScope.launch {
                OnlineRepository.deleteRoom(roomId)
            }
            finish()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        lifecycleScope.launch {
            OnlineRepository.abandonRoom(roomId)
        }
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}
