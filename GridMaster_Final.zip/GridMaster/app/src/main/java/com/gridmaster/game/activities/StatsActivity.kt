package com.gridmaster.game.activities

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.gridmaster.game.databinding.ActivityStatsBinding
import com.gridmaster.game.utils.*

class StatsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStatsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupUI()
        loadStats()
        animateStats()
    }

    private fun setupUI() {
        binding.btnBack.setOnClickListener {
            SoundManager.playClick()
            onBackPressed()
        }
    }

    private fun loadStats() {
        val stats = PreferencesManager.getStats()
        binding.apply {
            tvPlayerNameStats.text = PreferencesManager.playerName
            tvTotalGames.text      = stats.totalGames.toString()
            tvTotalWins.text       = stats.wins.toString()
            tvTotalLosses.text     = stats.losses.toString()
            tvTotalDraws.text      = stats.draws.toString()
            tvWinRate.text         = "${String.format("%.1f", stats.winRate)}%"
            tvWinsRobot.text       = stats.winsVsRobot.toString()
            tvLossesRobot.text     = stats.lossesVsRobot.toString()
            tvOnlineWins.text      = stats.onlineWins.toString()
            tvOnlineLosses.text    = stats.onlineLosses.toString()
            tvWinStreak.text       = stats.winStreak.toString()
            tvBestStreak.text      = stats.bestStreak.toString()

            // Win rate bar
            progressWinRate.progress = stats.winRate.toInt()

            // Achievement badges
            if (stats.wins >= 10) badgeWinner.visibility = View.VISIBLE
            if (stats.winsVsRobot >= 5) badgeRobotSlayer.visibility = View.VISIBLE
            if (stats.bestStreak >= 3) badgeStreak.visibility = View.VISIBLE
            if (stats.onlineWins >= 3) badgeOnline.visibility = View.VISIBLE
            if (stats.draws >= 5) badgeTactician.visibility = View.VISIBLE
        }
    }

    private fun animateStats() {
        val views = listOf(
            binding.cardOverall, binding.cardVsRobot, binding.cardOnline,
            binding.cardStreak, binding.cardBadges
        )
        views.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = 50f
            v.animate()
                .alpha(1f).translationY(0f)
                .setStartDelay(i * 100L)
                .setDuration(400)
                .start()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
