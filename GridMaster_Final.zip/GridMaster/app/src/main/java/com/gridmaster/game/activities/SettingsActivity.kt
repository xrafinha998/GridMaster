package com.gridmaster.game.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.gridmaster.game.databinding.ActivitySettingsBinding
import com.gridmaster.game.models.Difficulty
import com.gridmaster.game.utils.*

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupUI()
        loadSettings()
    }

    private fun setupUI() {
        binding.apply {
            btnBack.setOnClickListener {
                SoundManager.playClick()
                onBackPressed()
            }

            // Sound toggle
            switchSound.setOnCheckedChangeListener { _, checked ->
                PreferencesManager.isSoundEnabled = checked
                SoundManager.isSoundEnabled = checked
            }

            // Vibration toggle
            switchVibration.setOnCheckedChangeListener { _, checked ->
                PreferencesManager.isVibrationEnabled = checked
                SoundManager.isVibrationEnabled = checked
            }

            // Difficulty buttons
            btnDiffEasy.setOnClickListener {
                setDifficulty(Difficulty.EASY)
                SoundManager.playClick()
            }
            btnDiffMedium.setOnClickListener {
                setDifficulty(Difficulty.MEDIUM)
                SoundManager.playClick()
            }
            btnDiffHard.setOnClickListener {
                setDifficulty(Difficulty.HARD)
                SoundManager.playClick()
            }

            // Player name
            btnSaveName.setOnClickListener {
                SoundManager.playClick()
                val name = etPlayerName.text.toString().trim()
                if (name.isNotEmpty()) {
                    PreferencesManager.playerName = name.take(20)
                    showToast("Nome salvo!")
                    SoundManager.vibrateShort()
                }
            }

            // Reset stats
            btnResetStats.setOnClickListener {
                SoundManager.playClick()
                android.app.AlertDialog.Builder(this@SettingsActivity)
                    .setTitle("⚠️ Resetar Estatísticas")
                    .setMessage("Tem certeza? Todos os dados serão apagados.")
                    .setPositiveButton("Resetar") { _, _ ->
                        PreferencesManager.resetStats()
                        showToast("Estatísticas resetadas!")
                        SoundManager.vibrateShort()
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }

            // Version
            tvVersion.text = "Grid Master v1.0.0"
        }
    }

    private fun loadSettings() {
        binding.apply {
            switchSound.isChecked     = PreferencesManager.isSoundEnabled
            switchVibration.isChecked = PreferencesManager.isVibrationEnabled
            etPlayerName.setText(PreferencesManager.playerName)
            updateDifficultyUI(PreferencesManager.difficulty)
        }
    }

    private fun setDifficulty(difficulty: Difficulty) {
        PreferencesManager.difficulty = difficulty
        updateDifficultyUI(difficulty)
    }

    private fun updateDifficultyUI(difficulty: Difficulty) {
        val activeColor   = getColor(com.gridmaster.game.R.color.accent_blue)
        val inactiveColor = getColor(com.gridmaster.game.R.color.card_bg)

        binding.apply {
            btnDiffEasy.setBackgroundColor(if (difficulty == Difficulty.EASY) activeColor else inactiveColor)
            btnDiffMedium.setBackgroundColor(if (difficulty == Difficulty.MEDIUM) activeColor else inactiveColor)
            btnDiffHard.setBackgroundColor(if (difficulty == Difficulty.HARD) activeColor else inactiveColor)
            tvDiffDescription.text = difficulty.displayName()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
