package com.gridmaster.game.activities

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gridmaster.game.ai.AIEngine
import com.gridmaster.game.models.*
import com.gridmaster.game.utils.PreferencesManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class GameViewModel : ViewModel() {

    // ─── LiveData ─────────────────────────────────────────────────────────────
    private val _board       = MutableLiveData(Board())
    val board: LiveData<Board> = _board

    private val _currentTurn = MutableLiveData(Player.X)
    val currentTurn: LiveData<Player> = _currentTurn

    private val _gameState   = MutableLiveData(GameState.PLAYING)
    val gameState: LiveData<GameState> = _gameState

    private val _gameResult  = MutableLiveData<GameResult?>()
    val gameResult: LiveData<GameResult?> = _gameResult

    private val _aiThinking  = MutableLiveData(false)
    val aiThinking: LiveData<Boolean> = _aiThinking

    private val _aiMessage   = MutableLiveData<String?>()
    val aiMessage: LiveData<String?> = _aiMessage

    private val _scoreX      = MutableLiveData(0)
    val scoreX: LiveData<Int> = _scoreX

    private val _scoreO      = MutableLiveData(0)
    val scoreO: LiveData<Int> = _scoreO

    private val _drawCount   = MutableLiveData(0)
    val drawCount: LiveData<Int> = _drawCount

    // ─── State ────────────────────────────────────────────────────────────────
    var gameMode: GameMode = GameMode.VS_ROBOT
    var difficulty: Difficulty = PreferencesManager.difficulty
    var humanPlayer: Player = Player.X
    var aiPlayer: Player = Player.O

    private var aiJob: Job? = null

    // ─── Make Human Move ──────────────────────────────────────────────────────

    fun makeMove(index: Int) {
        val currentBoard = _board.value ?: return
        val state        = _gameState.value ?: return

        if (state != GameState.PLAYING) return
        if (!currentBoard.isValidMove(index)) return

        // Prevent human move during AI thinking
        if (_aiThinking.value == true) return

        // In VS_ROBOT, only allow human player
        if (gameMode == GameMode.VS_ROBOT && _currentTurn.value != humanPlayer) return

        val newBoard  = currentBoard.makeMove(index, _currentTurn.value!!)
        _board.value  = newBoard

        val result = checkGameResult(newBoard)
        if (result != null) {
            finishGame(result)
            return
        }

        // Switch turn
        _currentTurn.value = _currentTurn.value!!.opponent()

        // Trigger AI if needed
        if (gameMode == GameMode.VS_ROBOT && _currentTurn.value == aiPlayer) {
            triggerAI(newBoard)
        }
    }

    // ─── AI Turn ─────────────────────────────────────────────────────────────

    private fun triggerAI(currentBoard: Board) {
        aiJob?.cancel()
        aiJob = viewModelScope.launch {
            _aiThinking.value = true
            _aiMessage.value  = AIEngine.getAIThinkingMessage()

            val move = AIEngine.getBestMove(currentBoard, difficulty)

            _aiThinking.value = false
            _aiMessage.value  = null

            if (_gameState.value != GameState.PLAYING) return@launch
            if (move == -1) return@launch

            val newBoard      = currentBoard.makeMove(move, aiPlayer)
            _board.value      = newBoard
            _currentTurn.value = humanPlayer

            val result = checkGameResult(newBoard)
            if (result != null) {
                finishGame(result)
            }
        }
    }

    // ─── Game Result ─────────────────────────────────────────────────────────

    private fun checkGameResult(board: Board): GameResult? {
        val winner = board.checkWinner()
        return when {
            winner != Player.NONE -> GameResult(
                winner      = winner,
                gameState   = if (winner == Player.X) GameState.PLAYER_X_WIN else GameState.PLAYER_O_WIN,
                winningCombo = board.getWinningCombo(),
                totalMoves  = board.moveCount
            )
            board.isFull() -> GameResult(
                winner      = Player.NONE,
                gameState   = GameState.DRAW,
                winningCombo = null,
                totalMoves  = board.moveCount
            )
            else -> null
        }
    }

    private fun finishGame(result: GameResult) {
        _gameState.value = result.gameState
        _gameResult.value = result

        // Update scores
        when (result.gameState) {
            GameState.PLAYER_X_WIN -> _scoreX.value = (_scoreX.value ?: 0) + 1
            GameState.PLAYER_O_WIN -> _scoreO.value = (_scoreO.value ?: 0) + 1
            GameState.DRAW         -> _drawCount.value = (_drawCount.value ?: 0) + 1
            else -> {}
        }

        // Update stats
        when (gameMode) {
            GameMode.VS_ROBOT -> {
                when (result.winner) {
                    humanPlayer -> {
                        PreferencesManager.recordWin(vsRobot = true)
                        _aiMessage.value = AIEngine.getAILoseMessage()
                    }
                    aiPlayer    -> {
                        PreferencesManager.recordLoss(vsRobot = true)
                        _aiMessage.value = AIEngine.getAIWinMessage()
                    }
                    else        -> {
                        PreferencesManager.recordDraw()
                        _aiMessage.value = AIEngine.getAIDrawMessage()
                    }
                }
            }
            GameMode.LOCAL_TWO_PLAYER -> {
                when (result.gameState) {
                    GameState.PLAYER_X_WIN -> PreferencesManager.recordWin()
                    GameState.PLAYER_O_WIN -> PreferencesManager.recordLoss()
                    else                   -> PreferencesManager.recordDraw()
                }
            }
            else -> {}
        }
    }

    // ─── Restart ─────────────────────────────────────────────────────────────

    fun restartGame() {
        aiJob?.cancel()
        _board.value       = Board()
        _currentTurn.value = Player.X
        _gameState.value   = GameState.PLAYING
        _gameResult.value  = null
        _aiThinking.value  = false
        _aiMessage.value   = null

        // If AI goes first (O starts, but AI is X sometimes)
        if (gameMode == GameMode.VS_ROBOT && humanPlayer == Player.O) {
            triggerAI(Board())
        }
    }

    fun switchSides() {
        humanPlayer = humanPlayer.opponent()
        aiPlayer    = aiPlayer.opponent()
        restartGame()
    }

    override fun onCleared() {
        super.onCleared()
        aiJob?.cancel()
    }
}
