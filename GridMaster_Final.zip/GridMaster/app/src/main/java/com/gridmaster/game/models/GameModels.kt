package com.gridmaster.game.models

import java.util.UUID

// ─── Enums ─────────────────────────────────────────────────────────────────

enum class Player {
    X, O, NONE;

    fun opponent(): Player = when (this) {
        X    -> O
        O    -> X
        NONE -> NONE
    }

    fun symbol(): String = when (this) {
        X    -> "X"
        O    -> "O"
        NONE -> ""
    }
}

enum class GameMode {
    VS_ROBOT,
    ONLINE_MULTIPLAYER,
    LOCAL_TWO_PLAYER
}

enum class Difficulty {
    EASY, MEDIUM, HARD;

    fun displayName(): String = when (this) {
        EASY   -> "Fácil"
        MEDIUM -> "Médio"
        HARD   -> "Difícil (Imbatível)"
    }
}

enum class GameState {
    WAITING,
    PLAYING,
    PLAYER_X_WIN,
    PLAYER_O_WIN,
    DRAW,
    ABANDONED
}

// ─── Board ─────────────────────────────────────────────────────────────────

data class Board(
    val cells: Array<Player> = Array(9) { Player.NONE },
    val moveCount: Int = 0
) {
    fun copy(): Board = Board(cells.copyOf(), moveCount)

    fun makeMove(index: Int, player: Player): Board {
        require(cells[index] == Player.NONE) { "Cell $index is already occupied" }
        val newCells = cells.copyOf()
        newCells[index] = player
        return Board(newCells, moveCount + 1)
    }

    fun isValidMove(index: Int): Boolean = index in 0..8 && cells[index] == Player.NONE

    fun getAvailableMoves(): List<Int> = cells.indices.filter { cells[it] == Player.NONE }

    fun isFull(): Boolean = cells.none { it == Player.NONE }

    fun checkWinner(): Player {
        val wins = arrayOf(
            intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8), // rows
            intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8), // cols
            intArrayOf(0, 4, 8), intArrayOf(2, 4, 6)                        // diags
        )
        for (combo in wins) {
            val a = cells[combo[0]]
            if (a != Player.NONE && a == cells[combo[1]] && a == cells[combo[2]]) {
                return a
            }
        }
        return Player.NONE
    }

    fun getWinningCombo(): IntArray? {
        val wins = arrayOf(
            intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8),
            intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8),
            intArrayOf(0, 4, 8), intArrayOf(2, 4, 6)
        )
        for (combo in wins) {
            val a = cells[combo[0]]
            if (a != Player.NONE && a == cells[combo[1]] && a == cells[combo[2]]) {
                return combo
            }
        }
        return null
    }

    fun isGameOver(): Boolean = checkWinner() != Player.NONE || isFull()

    fun toFirebaseMap(): Map<String, Any> {
        return mapOf(
            "cells" to cells.map { it.name }.toList(),
            "moveCount" to moveCount
        )
    }

    companion object {
        fun fromFirebaseMap(map: Map<*, *>): Board {
            @Suppress("UNCHECKED_CAST")
            val cellList = map["cells"] as? List<String> ?: return Board()
            val cells = Array(9) { i ->
                try { Player.valueOf(cellList[i]) } catch (e: Exception) { Player.NONE }
            }
            val moveCount = (map["moveCount"] as? Long)?.toInt() ?: 0
            return Board(cells, moveCount)
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Board) return false
        return cells.contentEquals(other.cells) && moveCount == other.moveCount
    }

    override fun hashCode(): Int = cells.contentHashCode() * 31 + moveCount
}

// ─── Online Room ────────────────────────────────────────────────────────────

data class OnlineRoom(
    val roomId: String = UUID.randomUUID().toString().take(8).uppercase(),
    val hostId: String = "",
    val guestId: String = "",
    val hostName: String = "Player 1",
    val guestName: String = "Player 2",
    val hostIsX: Boolean = true,
    val board: Board = Board(),
    val currentTurn: Player = Player.X,
    val gameState: GameState = GameState.WAITING,
    val lastMoveTime: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirebaseMap(): Map<String, Any> {
        return mapOf(
            "roomId"       to roomId,
            "hostId"       to hostId,
            "guestId"      to guestId,
            "hostName"     to hostName,
            "guestName"    to guestName,
            "hostIsX"      to hostIsX,
            "board"        to board.toFirebaseMap(),
            "currentTurn"  to currentTurn.name,
            "gameState"    to gameState.name,
            "lastMoveTime" to lastMoveTime,
            "createdAt"    to createdAt
        )
    }

    companion object {
        fun fromFirebaseMap(map: Map<*, *>): OnlineRoom? {
            return try {
                @Suppress("UNCHECKED_CAST")
                val boardMap = map["board"] as? Map<String, Any> ?: return null
                OnlineRoom(
                    roomId      = map["roomId"] as? String ?: "",
                    hostId      = map["hostId"] as? String ?: "",
                    guestId     = map["guestId"] as? String ?: "",
                    hostName    = map["hostName"] as? String ?: "Player 1",
                    guestName   = map["guestName"] as? String ?: "Player 2",
                    hostIsX     = map["hostIsX"] as? Boolean ?: true,
                    board       = Board.fromFirebaseMap(boardMap),
                    currentTurn = Player.valueOf(map["currentTurn"] as? String ?: "X"),
                    gameState   = GameState.valueOf(map["gameState"] as? String ?: "WAITING"),
                    lastMoveTime= (map["lastMoveTime"] as? Long) ?: System.currentTimeMillis(),
                    createdAt   = (map["createdAt"] as? Long) ?: System.currentTimeMillis()
                )
            } catch (e: Exception) { null }
        }
    }
}

// ─── Stats ──────────────────────────────────────────────────────────────────

data class PlayerStats(
    val totalGames: Int = 0,
    val wins: Int = 0,
    val losses: Int = 0,
    val draws: Int = 0,
    val winsVsRobot: Int = 0,
    val lossesVsRobot: Int = 0,
    val onlineWins: Int = 0,
    val onlineLosses: Int = 0,
    val winStreak: Int = 0,
    val bestStreak: Int = 0
) {
    val winRate: Float get() = if (totalGames > 0) wins.toFloat() / totalGames * 100f else 0f
}

// ─── Game Result ─────────────────────────────────────────────────────────────

data class GameResult(
    val winner: Player,
    val gameState: GameState,
    val winningCombo: IntArray?,
    val totalMoves: Int
)
