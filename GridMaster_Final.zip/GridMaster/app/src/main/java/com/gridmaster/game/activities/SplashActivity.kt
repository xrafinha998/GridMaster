package com.gridmaster.game.activities

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gridmaster.game.databinding.ActivitySplashBinding
import com.gridmaster.game.utils.PreferencesManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        startAnimations()

        lifecycleScope.launch {
            delay(2800)
            goToMain()
        }
    }

    private fun startAnimations() {
        // Logo scale-in
        binding.ivLogo.apply {
            scaleX = 0f; scaleY = 0f; alpha = 0f
        }
        binding.tvAppName.apply {
            translationY = 80f; alpha = 0f
        }
        binding.tvTagline.apply {
            translationY = 60f; alpha = 0f
        }
        binding.progressBar.alpha = 0f

        val logoAnim = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(binding.ivLogo, "scaleX", 0f, 1.2f, 1f),
                ObjectAnimator.ofFloat(binding.ivLogo, "scaleY", 0f, 1.2f, 1f),
                ObjectAnimator.ofFloat(binding.ivLogo, "alpha",  0f, 1f)
            )
            duration = 700
            interpolator = OvershootInterpolator(2f)
            startDelay = 200
        }

        val titleAnim = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(binding.tvAppName, "translationY", 80f, 0f),
                ObjectAnimator.ofFloat(binding.tvAppName, "alpha", 0f, 1f)
            )
            duration = 500
            startDelay = 800
        }

        val taglineAnim = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(binding.tvTagline, "translationY", 60f, 0f),
                ObjectAnimator.ofFloat(binding.tvTagline, "alpha", 0f, 1f)
            )
            duration = 500
            startDelay = 1100
        }

        val progressAnim = ObjectAnimator.ofFloat(binding.progressBar, "alpha", 0f, 1f).apply {
            duration = 400
            startDelay = 1600
        }

        logoAnim.start()
        titleAnim.start()
        taglineAnim.start()
        progressAnim.start()
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
