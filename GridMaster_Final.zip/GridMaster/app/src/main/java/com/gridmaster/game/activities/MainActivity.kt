package com.gridmaster.game.activities
import com.gridmaster.game.R

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.gridmaster.game.databinding.ActivityMainBinding
import com.gridmaster.game.models.GameMode
import com.gridmaster.game.utils.PreferencesManager
import com.gridmaster.game.utils.SoundManager
import com.gridmaster.game.utils.animateBounce
import com.gridmaster.game.utils.showToast

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupUI()
        animateEntrance()
    }

    override fun onResume() {
        super.onResume()
        updatePlayerName()
        updateStats()
    }

    private fun setupUI() {
        binding.apply {
            btnVsRobot.setOnClickListener {
                SoundManager.playClick(); it.animateBounce()
                it.postDelayed({ startGame(GameMode.VS_ROBOT) }, 130)
            }
            btnOnline.setOnClickListener {
                SoundManager.playClick(); it.animateBounce()
                it.postDelayed({ startActivity(Intent(this@MainActivity, MatchmakingActivity::class.java)) }, 130)
            }
            btnTwoPlayer.setOnClickListener {
                SoundManager.playClick(); it.animateBounce()
                it.postDelayed({ startGame(GameMode.LOCAL_TWO_PLAYER) }, 130)
            }
            btnStats.setOnClickListener {
                SoundManager.playClick(); it.animateBounce()
                it.postDelayed({ startActivity(Intent(this@MainActivity, StatsActivity::class.java)) }, 130)
            }
            btnSettings.setOnClickListener {
                SoundManager.playClick(); it.animateBounce()
                it.postDelayed({ startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }, 130)
            }
            tvPlayerName.setOnClickListener { showEditNameDialog() }
        }
    }

    private fun animateEntrance() {
        val views = listOf(
            binding.ivLogo, binding.tvAppTitle,
            binding.tvPlayerName, binding.cardStats,
            binding.btnVsRobot, binding.btnOnline,
            binding.btnTwoPlayer, binding.btnStats, binding.btnSettings
        )
        views.forEachIndexed { i, view ->
            view.alpha = 0f; view.translationY = 50f
            view.animate().alpha(1f).translationY(0f)
                .setStartDelay(i * 70L).setDuration(380).start()
        }
    }

    private fun updatePlayerName() {
        binding.tvPlayerNameText.text = PreferencesManager.playerName
    }

    private fun updateStats() {
        val stats = PreferencesManager.getStats()
        binding.apply {
            tvStatGames.text = stats.totalGames.toString()
            tvStatWins.text  = stats.wins.toString()
            tvStatWinRate.text = "${String.format("%.0f", stats.winRate)}%"
        }
    }

    private fun startGame(mode: GameMode) {
        val intent = Intent(this, GameActivity::class.java)
        intent.putExtra(GameActivity.EXTRA_GAME_MODE, mode.name)
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    private fun showEditNameDialog() {
        val input = android.widget.EditText(this).apply {
            setText(PreferencesManager.playerName)
            hint = "Seu apelido"
            setPadding(40, 24, 40, 24)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("✏️ Editar Nome")
            .setView(input)
            .setPositiveButton("Salvar") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    PreferencesManager.playerName = name.take(20)
                    updatePlayerName()
                    SoundManager.vibrateShort()
                    showToast("Nome salvo!")
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
