package com.gridmaster.game.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gridmaster.game.databinding.ActivityMatchmakingBinding
import com.gridmaster.game.network.OnlineRepository
import com.gridmaster.game.utils.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

class MatchmakingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMatchmakingBinding
    private val myId: String get() = PreferencesManager.playerId
    private var searchJob: Job? = null
    private var isSearching = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMatchmakingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupUI()
    }

    private fun setupUI() {
        binding.apply {
            tvPlayerName.text = PreferencesManager.playerName

            // ─ Quick Match ─
            btnQuickMatch.setOnClickListener {
                SoundManager.playClick()
                it.animateBounce()
                startQuickMatch()
            }

            // ─ Create Room ─
            btnCreateRoom.setOnClickListener {
                SoundManager.playClick()
                it.animateBounce()
                createPrivateRoom()
            }

            // ─ Join Room ─
            btnJoinRoom.setOnClickListener {
                SoundManager.playClick()
                it.animateBounce()
                showJoinDialog()
            }

            // ─ Cancel ─
            btnCancel.setOnClickListener {
                SoundManager.playClick()
                cancelSearch()
            }

            btnBack.setOnClickListener {
                SoundManager.playClick()
                cancelSearch()
                onBackPressed()
            }
        }
    }

    private fun startQuickMatch() {
        setSearchingState(true, "🔍 Procurando adversário...")
        searchJob = lifecycleScope.launch {
            try {
                val roomId = OnlineRepository.joinMatchmaking(myId, PreferencesManager.playerName)
                if (roomId != null) {
                    // Joined existing room as guest
                    startOnlineGame(roomId, isHost = false)
                } else {
                    // Waiting – observe for room creation where we're guest
                    binding.tvMatchStatus.text = "⏳ Aguardando adversário..."
                    OnlineRepository.observeMatchmaking(myId).collectLatest { foundRoomId ->
                        if (foundRoomId != null) {
                            startOnlineGame(foundRoomId, isHost = false)
                        }
                    }
                }
            } catch (e: Exception) {
                if (isActive) {
                    setSearchingState(false)
                    showToast("Erro de conexão. Verifique o internet.")
                }
            }
        }
    }

    private fun createPrivateRoom() {
        setSearchingState(true, "🏠 Criando sala...")
        lifecycleScope.launch {
            try {
                val room = OnlineRepository.createRoom(myId, PreferencesManager.playerName)
                binding.tvMatchStatus.text = "🏠 Sala criada!\nCódigo: ${room.roomId}\nAguardando oponente..."
                binding.tvRoomCode.visibility = View.VISIBLE
                binding.tvRoomCode.text = "Código: ${room.roomId}"

                // Watch for guest
                OnlineRepository.observeRoom(room.roomId).collectLatest { updatedRoom ->
                    if (updatedRoom?.guestId?.isNotEmpty() == true) {
                        startOnlineGame(room.roomId, isHost = true)
                    }
                }
            } catch (e: Exception) {
                setSearchingState(false)
                showToast("Erro ao criar sala.")
            }
        }
    }

    private fun showJoinDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Código da sala (ex: AB12CD34)"
            setPadding(40, 20, 40, 20)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("🔗 Entrar na Sala")
            .setView(input)
            .setPositiveButton("Entrar") { _, _ ->
                val code = input.text.toString().trim().uppercase()
                if (code.length >= 6) {
                    joinPrivateRoom(code)
                } else {
                    showToast("Código inválido")
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun joinPrivateRoom(roomId: String) {
        setSearchingState(true, "🔗 Conectando à sala $roomId...")
        lifecycleScope.launch {
            try {
                val room = OnlineRepository.joinRoom(roomId, myId, PreferencesManager.playerName)
                if (room != null) {
                    startOnlineGame(roomId, isHost = false)
                } else {
                    setSearchingState(false)
                    showToast("Sala não encontrada ou cheia.", true)
                }
            } catch (e: Exception) {
                setSearchingState(false)
                showToast("Erro ao entrar na sala.")
            }
        }
    }

    private fun startOnlineGame(roomId: String, isHost: Boolean) {
        val intent = Intent(this, OnlineGameActivity::class.java).apply {
            putExtra(OnlineGameActivity.EXTRA_ROOM_ID, roomId)
            putExtra(OnlineGameActivity.EXTRA_PLAYER_ID, myId)
            putExtra(OnlineGameActivity.EXTRA_IS_HOST, isHost)
        }
        startActivity(intent)
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
        finish()
    }

    private fun cancelSearch() {
        searchJob?.cancel()
        lifecycleScope.launch {
            OnlineRepository.cancelMatchmaking(myId)
        }
        setSearchingState(false)
    }

    private fun setSearchingState(searching: Boolean, message: String = "") {
        isSearching = searching
        binding.apply {
            btnQuickMatch.isEnabled  = !searching
            btnCreateRoom.isEnabled  = !searching
            btnJoinRoom.isEnabled    = !searching
            progressSearching.visibility = if (searching) View.VISIBLE else View.GONE
            btnCancel.visibility     = if (searching) View.VISIBLE else View.GONE
            tvMatchStatus.text       = message
            tvMatchStatus.visibility = if (message.isNotEmpty()) View.VISIBLE else View.GONE
            tvRoomCode.visibility    = View.GONE
        }
    }

    override fun onBackPressed() {
        cancelSearch()
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
