package com.gridmaster.game.utils

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.os.Build
import com.gridmaster.game.R

object SoundManager {

    private var soundPool: SoundPool? = null
    private var soundMove: Int = 0
    private var soundWin: Int = 0
    private var soundLose: Int = 0
    private var soundDraw: Int = 0
    private var soundClick: Int = 0
    private var soundAiMove: Int = 0

    private var vibrator: Vibrator? = null
    private var isInitialized = false

    var isSoundEnabled: Boolean = true
    var isVibrationEnabled: Boolean = true

    fun init(context: Context) {
        if (isInitialized) return
        isInitialized = true

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(audioAttributes)
            .build()

        // Load sounds (WAV/OGG from raw resources)
        // Note: These will use system generated tones if files not present
        try {
            soundMove   = soundPool?.load(context, R.raw.sound_move, 1)   ?: 0
            soundWin    = soundPool?.load(context, R.raw.sound_win, 1)    ?: 0
            soundLose   = soundPool?.load(context, R.raw.sound_lose, 1)   ?: 0
            soundDraw   = soundPool?.load(context, R.raw.sound_draw, 1)   ?: 0
            soundClick  = soundPool?.load(context, R.raw.sound_click, 1)  ?: 0
            soundAiMove = soundPool?.load(context, R.raw.sound_ai_move, 1) ?: 0
        } catch (e: Exception) {
            // Sounds not available
        }

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    fun playMove() = play(soundMove)
    fun playAiMove() = play(soundAiMove)
    fun playWin() { play(soundWin); vibrate(longArrayOf(0, 100, 50, 100)) }
    fun playLose() { play(soundLose); vibrate(longArrayOf(0, 300)) }
    fun playDraw() { play(soundDraw); vibrate(longArrayOf(0, 150)) }
    fun playClick() = play(soundClick)

    private fun play(soundId: Int) {
        if (!isSoundEnabled || soundId == 0) return
        soundPool?.play(soundId, 1f, 1f, 1, 0, 1f)
    }

    fun vibrate(pattern: LongArray) {
        if (!isVibrationEnabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, -1)
        }
    }

    fun vibrateShort() = vibrate(longArrayOf(0, 50))

    fun release() {
        soundPool?.release()
        soundPool = null
        isInitialized = false
    }
}
