package com.gridmaster.game.utils

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.AnimatorSet
import android.content.Context
import android.view.View
import android.view.animation.OvershootInterpolator
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Toast
import androidx.fragment.app.Fragment

fun View.animateBounce() {
    val scaleX = ObjectAnimator.ofFloat(this, "scaleX", 1f, 1.3f, 0.9f, 1.05f, 1f)
    val scaleY = ObjectAnimator.ofFloat(this, "scaleY", 1f, 1.3f, 0.9f, 1.05f, 1f)
    AnimatorSet().apply {
        playTogether(scaleX, scaleY)
        duration = 400
        interpolator = OvershootInterpolator()
        start()
    }
}

fun View.animateShake() {
    ObjectAnimator.ofFloat(this, "translationX",
        0f, -20f, 20f, -15f, 15f, -10f, 10f, 0f
    ).apply {
        duration = 500
        start()
    }
}

fun View.animatePop(onEnd: (() -> Unit)? = null) {
    this.scaleX = 0f
    this.scaleY = 0f
    this.alpha  = 0f
    this.visibility = View.VISIBLE
    val scaleX = ObjectAnimator.ofFloat(this, "scaleX", 0f, 1.2f, 1f)
    val scaleY = ObjectAnimator.ofFloat(this, "scaleY", 0f, 1.2f, 1f)
    val alpha  = ObjectAnimator.ofFloat(this, "alpha",  0f, 1f)
    AnimatorSet().apply {
        playTogether(scaleX, scaleY, alpha)
        duration = 350
        interpolator = OvershootInterpolator(2f)
        addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onEnd?.invoke() }
        })
        start()
    }
}

fun View.animateFadeIn(duration: Long = 300) {
    this.alpha = 0f
    this.visibility = View.VISIBLE
    this.animate().alpha(1f).setDuration(duration)
        .setInterpolator(AccelerateDecelerateInterpolator()).start()
}

fun View.animateFadeOut(duration: Long = 300, onEnd: (() -> Unit)? = null) {
    this.animate().alpha(0f).setDuration(duration)
        .setInterpolator(AccelerateDecelerateInterpolator())
        .withEndAction {
            this.visibility = View.GONE
            onEnd?.invoke()
        }.start()
}

fun View.animateWinHighlight() {
    ObjectAnimator.ofFloat(this, "alpha", 1f, 0.3f, 1f, 0.3f, 1f).apply {
        duration = 1000
        repeatCount = ObjectAnimator.INFINITE
        start()
    }
}

fun View.setClickWithAnimation(onClick: () -> Unit) {
    setOnClickListener {
        animateBounce()
        it.postDelayed({ onClick() }, 100)
    }
}

fun Context.showToast(message: String, long: Boolean = false) {
    Toast.makeText(this, message, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
}

fun Fragment.showToast(message: String, long: Boolean = false) {
    requireContext().showToast(message, long)
}
